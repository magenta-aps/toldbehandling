class TenQTransaction(dict):
    pass
